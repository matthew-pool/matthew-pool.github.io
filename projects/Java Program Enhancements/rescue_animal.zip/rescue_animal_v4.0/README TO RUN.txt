Insall Java v22 (or greater)


In a Terminal, run the following commands:
	cd \rescue_animal_v4.0
	java -jar target/rescue_animal_v4.0.jar
