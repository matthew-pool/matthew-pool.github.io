module rescueAnimal {
	exports rescueAnimal;
	requires java.base;
}
