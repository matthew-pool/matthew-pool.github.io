var searchData=
[
  ['release_20notes_513',['Release notes',['../news.html',1,'']]],
  ['red_514',['red',['../structGLFWgammaramp.html#a2cce5d968734b685623eef913e635138',1,'GLFWgammaramp']]],
  ['redbits_515',['redBits',['../structGLFWvidmode.html#a6066c4ecd251098700062d3b735dba1b',1,'GLFWvidmode']]],
  ['refreshrate_516',['refreshRate',['../structGLFWvidmode.html#a791bdd6c7697b09f7e9c97054bf05649',1,'GLFWvidmode']]]
];
